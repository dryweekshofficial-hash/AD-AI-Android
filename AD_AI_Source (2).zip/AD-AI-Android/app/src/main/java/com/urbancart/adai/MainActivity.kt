package com.urbancart.adai

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

private val Navy = Color(0xFF07111F)
private val Panel = Color(0xFF102236)
private val Cyan = Color(0xFF66E3FF)

class MainActivity : ComponentActivity() {
    private var tts: TextToSpeech? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) tts?.language = Locale("hi", "IN")
        }
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Cyan, background = Navy, surface = Panel,
                onPrimary = Navy, onBackground = Color.White, onSurface = Color.White
            )) {
                ADHome(
                    context = this,
                    speak = { text -> tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "adai_reply") }
                )
            }
        }
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}

data class ChatLine(val who: String, val text: String)

@Composable
private fun ADHome(context: ComponentActivity, speak: (String) -> Unit) {
    val prefs = remember { securePrefs(context) }
    var apiKey by remember { mutableStateOf(prefs.getString("gemini_api_key", "") ?: "") }
    var showKey by remember { mutableStateOf(false) }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var speakReplies by remember { mutableStateOf(true) }
    var useLiveSearch by remember { mutableStateOf(true) }
    var status by remember { mutableStateOf("तैयार हूँ। API Key सेट करके मुझसे बात करें।") }
    val messages = remember { mutableStateListOf<ChatLine>() }
    val scope = rememberCoroutineScope()

    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (!granted) status = "बोलकर इस्तेमाल करने के लिए माइक्रोफोन अनुमति चाहिए।"
    }
    val cameraPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        status = if (granted) "कैमरा अनुमति मिल गई। Torch बटन दोबारा दबाएँ।" else "Torch के लिए Android कैमरा अनुमति जरूरी है।"
    }
    val speechLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!spoken.isNullOrBlank()) input = spoken
    }

    fun startListening() {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            micPermission.launch(Manifest.permission.RECORD_AUDIO)
            return
        }
        try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_PROMPT, "AD AI से बोलिए")
            }
            speechLauncher.launch(intent)
        } catch (_: Exception) {
            status = "इस फोन में Speech Recognition उपलब्ध नहीं है।"
        }
    }

    fun doPhoneAction(command: String): Boolean {
        val c = command.lowercase(Locale.ROOT)
        return try {
            when {
                listOf("youtube kholo", "यूट्यूब खोलो", "open youtube").any { c.contains(it) } -> {
                    val launch = context.packageManager.getLaunchIntentForPackage("com.google.android.youtube")
                    if (launch != null) context.startActivity(launch) else context.startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://www.youtube.com")))
                    status = "YouTube खोलने का अनुरोध किया।"; true
                }
                listOf("settings kholo", "सेटिंग खोलो", "open settings").any { c.contains(it) } -> {
                    context.startActivity(Intent(android.provider.Settings.ACTION_SETTINGS)); status = "फोन की Settings खोली।"; true
                }
                listOf("alarm lagao", "अलार्म लगाओ", "set alarm").any { c.contains(it) } -> {
                    context.startActivity(Intent(android.provider.AlarmClock.ACTION_SET_ALARM).putExtra(android.provider.AlarmClock.EXTRA_MESSAGE, "AD AI Reminder")); status = "अलार्म सेट करने की स्क्रीन खोली। समय चुनकर पुष्टि करें।"; true
                }
                listOf("web search", "google par search", "गूगल पर खोजो", "search karo").any { c.contains(it) } -> {
                    context.startActivity(Intent(Intent.ACTION_WEB_SEARCH).putExtra("query", command)); status = "वेब सर्च खोला।"; true
                }
                else -> false
            }
        } catch (e: Exception) {
            status = "यह फोन action नहीं हो पाया: ${e.message ?: "अनजान त्रुटि"}"; true
        }
    }

    fun sendMessage() {
        val question = input.trim()
        if (question.isEmpty() || busy) return
        input = ""
        messages.add(ChatLine("आप", question))
        if (doPhoneAction(question)) return
        if (apiKey.isBlank()) {
            val warning = "पहले ऊपर Gemini API Key डालकर ‘Key Save’ दबाएँ।"
            messages.add(ChatLine("AD AI", warning)); status = warning; return
        }
        busy = true
        status = "AD AI सोच रहा है…"
        scope.launch {
            val history = messages.dropLast(1).takeLast(12).map { it.who to it.text } + ("आप" to question)
            val result = withContext(Dispatchers.IO) { askGemini(apiKey, history, useLiveSearch) }
            busy = false
            result.onSuccess { answer ->
                messages.add(ChatLine("AD AI", answer))
                status = "जवाब तैयार है।"
                if (speakReplies) speak(answer)
            }.onFailure { error ->
                val msg = "AI से कनेक्शन नहीं हुआ: ${error.message ?: "कृपया API Key और इंटरनेट जाँचें"}"
                messages.add(ChatLine("AD AI", msg)); status = msg
            }
        }
    }

    Surface(modifier = Modifier.fillMaxSize(), color = Navy) {
        Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Column {
                    Text("AD AI", style = MaterialTheme.typography.headlineLarge, color = Cyan, fontWeight = FontWeight.Bold)
                    Text("YOUR ANDROID AI ASSISTANT", style = MaterialTheme.typography.labelSmall, color = Color.LightGray)
                }
                Text("● ONLINE READY", color = Cyan, style = MaterialTheme.typography.labelSmall)
            }

            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Gemini API सेटिंग", fontWeight = FontWeight.SemiBold, color = Cyan)
                    OutlinedTextField(
                        value = apiKey,
                        onValueChange = { apiKey = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Google Gemini API Key") },
                        singleLine = true,
                        visualTransformation = if (showKey) androidx.compose.ui.text.input.VisualTransformation.None else PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
                    )
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { showKey = !showKey }) { Text(if (showKey) "Hide" else "Show") }
                        Button(onClick = {
                            try {
                                prefs.edit().putString("gemini_api_key", apiKey.trim()).apply()
                                status = "API Key इस डिवाइस पर सुरक्षित preferences में सेव करने का प्रयास किया गया।"
                            } catch (e: Exception) { status = "Key save नहीं हुई: ${e.message}" }
                        }) { Text("Key Save") }
                    }
                    Text("Key को किसी के साथ साझा न करें। इस ऐप का AI जवाब देने के लिए इंटरनेट और वैध API Key चाहिए।", color = Color.LightGray, style = MaterialTheme.typography.bodySmall)
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Text("जवाब आवाज़ में सुनाएँ", color = Color.White)
                Switch(checked = speakReplies, onCheckedChange = { speakReplies = it })
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.weight(1f)) {
                    Text("Live web search", color = Color.White)
                    Text("ताज़ा जानकारी के लिए Google Search grounding", color = Color.LightGray, style = MaterialTheme.typography.bodySmall)
                }
                Switch(checked = useLiveSearch, onCheckedChange = { useLiveSearch = it })
            }

            Card(modifier = Modifier.weight(1f).fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
                if (messages.isEmpty()) {
                    Box(Modifier.fillMaxSize().padding(20.dp), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("◉", color = Cyan, style = MaterialTheme.typography.displayLarge)
                            Text("नमस्ते! मैं AD AI हूँ।", color = Color.White, fontWeight = FontWeight.Bold)
                            Text("अपना सवाल लिखें या माइक से बोलें।", color = Color.LightGray)
                        }
                    }
                } else {
                    LazyColumn(Modifier.fillMaxSize().padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        itemsIndexed(messages) { _, line ->
                            Column(Modifier.fillMaxWidth().background(if (line.who == "आप") Color(0xFF173A53) else Color(0xFF0A1827), RoundedCornerShape(12.dp)).padding(10.dp)) {
                                Text(line.who, color = Cyan, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(3.dp))
                                Text(line.text, color = Color.White)
                            }
                        }
                    }
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Text(status, color = Color.LightGray, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                OutlinedButton(onClick = {
                    messages.clear()
                    status = "इस बातचीत को स्क्रीन से साफ कर दिया गया।"
                }) { Text("Clear chat") }
            }
            OutlinedTextField(value = input, onValueChange = { input = it }, modifier = Modifier.fillMaxWidth(), label = { Text("AD AI से कुछ भी पूछें…") })
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { startListening() }, modifier = Modifier.weight(1f)) { Text("🎙 बोलें") }
                Button(onClick = { sendMessage() }, enabled = !busy, modifier = Modifier.weight(1f)) { Text(if (busy) "सोच रहा…" else "भेजें ➤") }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = {
                    if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                        cameraPermission.launch(Manifest.permission.CAMERA)
                    } else try {
                        val cm = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
                        val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
                        if (id == null) status = "इस फोन में Flashlight उपलब्ध नहीं है।" else {
                            val current = prefs.getBoolean("torch_on", false)
                            cm.setTorchMode(id, !current)
                            prefs.edit().putBoolean("torch_on", !current).apply()
                            status = if (!current) "Flashlight चालू की।" else "Flashlight बंद की।"
                        }
                    } catch (e: Exception) { status = "Flashlight नहीं चल पाई: ${e.message ?: "permission/device error"}" }
                }, modifier = Modifier.weight(1f)) { Text("🔦 Torch") }
                Button(onClick = { context.startActivity(Intent(android.provider.Settings.ACTION_SETTINGS)) }, modifier = Modifier.weight(1f)) { Text("⚙ Settings") }
            }
        }
    }
}

private fun securePrefs(context: Context): android.content.SharedPreferences {
    val masterKey = MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
    return EncryptedSharedPreferences.create(
        context,
        "ad_ai_secure_prefs",
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )
}

private fun askGemini(apiKey: String, history: List<Pair<String, String>>, useLiveSearch: Boolean): Result<String> = runCatching {
    require(apiKey.isNotBlank()) { "Gemini API Key खाली है" }
    val url = URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent")
    val connection = (url.openConnection() as HttpURLConnection).apply {
        requestMethod = "POST"
        connectTimeout = 20000
        readTimeout = 60000
        doOutput = true
        setRequestProperty("Content-Type", "application/json; charset=utf-8")
        // Keep the key out of the URL so it is less likely to appear in URL logs.
        setRequestProperty("x-goog-api-key", apiKey)
    }

    val contents = JSONArray()
    history.forEach { (who, text) ->
        val role = if (who == "आप") "user" else "model"
        contents.put(JSONObject()
            .put("role", role)
            .put("parts", JSONArray().put(JSONObject().put("text", text))))
    }
    if (contents.length() == 0) error("कृपया पहले सवाल लिखें")

    val systemInstruction = JSONObject().put("parts", JSONArray().put(JSONObject().put(
        "text",
        "You are AD AI, a helpful personal assistant for an Android phone. Reply naturally in Hindi by default and understand Hindi, English, and Hinglish. Be clear, practical, and honest. Never claim to have controlled the phone or completed an action unless the app confirms it. When web search grounding is available, use it for current or changing facts and clearly distinguish sourced information from general knowledge. If live information cannot be verified, say so. Do not invent citations, prices, news, weather, or real-time facts."
    )))
    val body = JSONObject()
        .put("systemInstruction", systemInstruction)
        .put("contents", contents)
        .put("generationConfig", JSONObject().put("temperature", 0.5).put("maxOutputTokens", 1536))
    if (useLiveSearch) {
        body.put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))
    }

    try {
        connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val responseText = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
        val json = try { JSONObject(responseText) } catch (_: Exception) { error("AI सेवा से पढ़ने योग्य जवाब नहीं मिला (HTTP $code)") }
        if (code !in 200..299) {
            val apiMessage = json.optJSONObject("error")?.optString("message")?.takeIf { it.isNotBlank() } ?: "HTTP $code"
            error(when (code) {
                400 -> "API अनुरोध गलत है: $apiMessage"
                401, 403 -> "API Key या अनुमति की समस्या: $apiMessage"
                429 -> "API सीमा/कोटा पूरा हो सकता है। थोड़ी देर बाद कोशिश करें।"
                else -> "Gemini API त्रुटि ($code): $apiMessage"
            })
        }
        val candidates = json.optJSONArray("candidates") ?: error("AI ने कोई जवाब नहीं दिया")
        val first = candidates.optJSONObject(0) ?: error("AI का जवाब खाली है")
        val parts = first.optJSONObject("content")?.optJSONArray("parts") ?: error("जवाब खाली है")
        val answer = buildString {
            for (i in 0 until parts.length()) {
                val part = parts.optJSONObject(i)
                if (part != null) append(part.optString("text", ""))
            }
        }.trim()
        if (answer.isBlank()) error("AI का जवाब खाली है")

        // Add source URLs returned by Google's grounding metadata when present.
        val grounding = first.optJSONObject("groundingMetadata")
        val chunks = grounding?.optJSONArray("groundingChunks")
        val sources = linkedMapOf<String, String>()
        if (chunks != null) {
            for (i in 0 until chunks.length()) {
                val web = chunks.optJSONObject(i)?.optJSONObject("web") ?: continue
                val uri = web.optString("uri", "")
                val title = web.optString("title", "वेब स्रोत")
                if (uri.startsWith("https://") || uri.startsWith("http://")) sources.putIfAbsent(uri, title)
            }
        }
        if (useLiveSearch && sources.isNotEmpty()) {
            answer + "\n\nस्रोत:\n" + sources.entries.take(5).joinToString("\n") { "• ${it.value}: ${it.key}" }
        } else answer
    } finally {
        connection.disconnect()
    }
}
